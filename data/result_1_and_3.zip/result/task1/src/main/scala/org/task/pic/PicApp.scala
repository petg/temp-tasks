package org.task.pic

import java.awt.image.Raster
import java.io.File
import javax.imageio.ImageIO

object PicApp extends App {

  val png: Raster = ImageIO.read(new File("./data/Exercise_1_nordea.png")).getData
  val iArray:Array[Int] = null

  def splitBySize(s: String, n: Int, resultBuffer: List[String] = List()): List[String] =
    if (s.size < n)  (s :: resultBuffer).reverse
    else {
      val (s1, s2) = s.splitAt(n)
      splitBySize(s2, n, s1 :: resultBuffer)
    }

  val byteCode =
  List.range(0, png.getHeight - 1)
    .flatMap(y =>  List.range(0, png.getWidth - 1)
      .map(x => png.getPixel(x,y, iArray).toList
      )
    )
    .flatten
    .map {
      case 191 => "0"
      case 255 => "1"
      case _ => ""
    }
    .mkString

  val result2 =
  splitBySize(byteCode,8)
    .map(s => Integer.parseInt(s,2))
    .filter(i => i > 30 && i < 126)
    .map(_.toChar)
    .mkString

  println(result2)

}
