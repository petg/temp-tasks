package org.task.dataset

import org.scalatest.flatspec.AnyFlatSpec

class SimilarityToolSimpleSpec extends AnyFlatSpec {

  val caseList =
    (    // String1 , String2, Left bound, Right bound
         ("Hello My Friend "," my FRIEND hello ", 100, 100)
      :: ("Hello My Friend "," haha ", 0, 10)
      :: ("Hello My Friend "," my hello ", 60, 80)
      :: ("Hello My Friend "," my FRIEND ", 60, 80)
      :: ("","", 100, 100)
      :: Nil)


  "check ' hi there ' and 'HI THERE' " should  " return 100% " in {

    caseList.foreach(c => {
        val similarity = SimilarityToolSimple.giveMeSimilarity(c._1, c._2)
        assert(
          c._3 <=  similarity && similarity <= c._4,
          s"$c"
        )
      })
  }
  "(Functional) check ' hi there ' and 'HI THERE' " should  " return 100% " in {
    caseList
      .foreach(c => {
        val similarity = SimilarityToolSimple.giveMeSimilarityFunctional(c._1, c._2)
        assert(
          c._3 <=  similarity && similarity <= c._4,
          s"$c"
        )
      })
  }
}
