package org.task.dataset

import org.scalatest.flatspec.AnyFlatSpec

import scala.collection.mutable

class WordUtilSpec extends AnyFlatSpec {

  "check(AAA, AAA)" should " return 0 " in {
    (    ("AAA", "AAA", 0)
      :: ("AAA", "aaa", 0)
      :: ("AAA", "ABB", 2)
      :: ("AAA", "AAB", 1)
      :: ("AAA", "BBA", 2)
      :: ("AAA", "BBB", 3)
      :: ("AAA", "BBBB", 4)
      :: Nil)
    .foreach( s =>
      assert(
        WordUtil.twoWordDifference(s._1, s._2) == s._3, s"case: ${s}"
      )
    )
  }



}
