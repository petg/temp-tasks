package org.task.dataset

object WordUtil {

  def twoWordDifference(word1: String, word2: String): Int = {
    val charArray1 = word1.toLowerCase.trim.toCharArray
    val charArray2 = word2.toLowerCase.trim.toCharArray
    val s1Size = charArray1.length
    val s2Size = charArray2.length

    def diff(i: Int, j: Int, strings: (Array[Char], Array[Char])  ):Int =  (i, j) match {
      case (0, 0) => 0
      case (0, jv) if jv > 0 =>  jv
      case (iv, 0) if iv > 0 =>  iv
      case (iv, jv) if iv > 0 && jv > 0 =>
        minOf3 (
          diff(i, j - 1, strings) + 1,
          diff(i - 1, j, strings) + 1,
          diff(i - 1, j - 1, strings) + letterDiff(strings._1(i-1), strings._2(j-1))
        )
    }

    def minOf3(i: Int, i1: Int, i2: Int) =
      if (i <= i1)
        if (i <= i2) i
        else  i2
      else
        if (i1 <= i2) i1
        else i2

    def letterDiff(a: Int, b:Int) =
      if (a==b) 0
      else 1

    diff(s1Size, s2Size, (charArray1,charArray2))
  }

}
