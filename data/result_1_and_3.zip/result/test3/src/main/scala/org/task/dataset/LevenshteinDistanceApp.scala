package org.task.dataset

class LevenshteinDistanceApp  {

  def main(args: Array[String]): Unit =
    if (checkCommandLineParameters(args))
      //SimilarityToolSimple.giveMeSimilarity(args(0), args(1))
      SimilarityToolSimple.giveMeSimilarityFunctional(args(0), args(1))
    else
      println(
        """run with parameters: program \"text1\" \"text2\"
          |""".stripMargin)

  def checkCommandLineParameters(args: Array[String]) =
    args.size == 2
}
