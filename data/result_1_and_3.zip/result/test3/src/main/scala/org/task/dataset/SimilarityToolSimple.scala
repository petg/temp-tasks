package org.task.dataset

import scala.collection.mutable

object SimilarityToolSimple {

  def giveMeSimilarity(string1: String, string2: String): Int = {

    val list = string1.trim.split("\\s+")
    val list2 = string2.trim.split("\\s+")

    val list1Size = list.foldLeft(0)(_ + _.size)
    val list2Size = list2.foldLeft(0)(_ + _.size)

    val allListsSize = list1Size + list2Size

    val result = list.zipWithIndex.map(s => {
      list2.zipWithIndex.map(s2 => {
        (s, s2, WordUtil.twoWordDifference(s._1, s2._1))
      })
    }).flatten

    val strSet1: mutable.Map[(String, Int),Int] = mutable.Map.empty
    val strSet2: mutable.Map[(String, Int),Int] = mutable.Map.empty

    result.map { s =>
      val w1 = s._1
      val w2 = s._2
      val diff = s._3

      val b1 = strSet1.getOrElse(w1, diff) min diff
      val b2 = strSet2.getOrElse(w2, diff) min diff

      strSet1(w1) = b1
      strSet2(w2) = b2
    }



    val differs1 = strSet1.foldLeft(0)(_ + _._2)
    val differs2 = strSet2.foldLeft(0)(_ + _._2)

    val differsAll = differs1 + differs2

    /***
      100 % - is a all strings size sum / not correct in case of checking not empty line with empty line
            - is a max of difference and  all strings size sum
     ***/
    val maxSizeAs100percent = differsAll max allListsSize

    /***
     *  empty lines are equal
     ***/
    val resultDiff =
      if (maxSizeAs100percent > 0)
        differsAll * 100 / maxSizeAs100percent
      else 0

    val similarity = 100 - resultDiff

    /*
    println(s"result: $result")
    println(strSet1)
    println(strSet2)
    println(s"differsAll($differsAll) = $differs1 + $differs2")
    println(s"resultDiff($resultDiff) = $differsAll * 100 / $allListsSize")
    println(s"similarity($similarity) = 100 - $resultDiff")
    println(similarity)*/
    similarity
  }

  def giveMeSimilarityFunctional(string1: String, string2: String): Int = {

    val list = string1.trim.split("\\s+")
    val list2 = string2.trim.split("\\s+")

    val list1Size = list.foldLeft(0)(_ + _.size)
    val list2Size = list2.foldLeft(0)(_ + _.size)

    val allListsSize = list1Size + list2Size

    val result = list.zipWithIndex.map(s => {
      list2.zipWithIndex.map(s2 => {
        (s, s2, WordUtil.twoWordDifference(s._1, s2._1))
      })
    }).flatten

    val (strSet1, strSet2) = result.foldLeft((Map[(String, Int),Int](),Map[(String, Int),Int]()))(
      (maps, listItem) => {
        val w1 = listItem._1
        val w2 = listItem._2
        val diff = listItem._3

        val b1 = maps._1.getOrElse(w1, diff) min diff
        val b2 = maps._2.getOrElse(w2, diff) min diff

        val maps1 = maps._1 + (w1 -> b1)
        val maps2 = maps._2 + (w2 -> b2)
        (maps1, maps2)
      })



    val differs1 = strSet1.foldLeft(0)(_ + _._2)
    val differs2 = strSet2.foldLeft(0)(_ + _._2)

    val differsAll = differs1 + differs2

    /***
      100 % - is a all strings size sum / not correct in case of checking not empty line with empty line
            - is a max of difference and  all strings size sum
     ***/
    val maxSizeAs100percent = differsAll max allListsSize
    /***
     *  empty lines are equal
     ***/
    val resultDiff =
      if (maxSizeAs100percent > 0)
        differsAll * 100 / maxSizeAs100percent
      else 0


    val similarity = 100 - resultDiff

    /*
    println(s"result: $result")
    println(strSet1)
    println(strSet2)
    println(s"differsAll($differsAll) = $differs1 + $differs2")
    println(s"resultDiff($resultDiff) = $differsAll * 100 / $allListsSize")
    println(s"similarity($similarity) = 100 - $resultDiff")
    println(similarity)*/
    similarity
  }

}
